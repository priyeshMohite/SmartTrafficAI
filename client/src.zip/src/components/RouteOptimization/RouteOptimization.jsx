import "./RouteOptimization.css";

import { useEffect, useState } from "react";

import trafficData from "../../data/trafficData";


function RouteOptimization({ incident }) {

  const [isCalculating, setIsCalculating] = useState(false);
  const [routeReady, setRouteReady] = useState(false);


  /* ==========================================
     ROUTE ANALYSIS ANIMATION
  ========================================== */

  useEffect(() => {

    if (!incident) {

      setIsCalculating(false);
      setRouteReady(false);

      return;

    }


    setIsCalculating(true);
    setRouteReady(false);


    const timer = setTimeout(() => {

      setIsCalculating(false);
      setRouteReady(true);

    }, 1000);


    return () => clearTimeout(timer);

  }, [incident]);


  /* ==========================================
     FIND ALTERNATE ROUTE
  ========================================== */

  const getAlternateRoute = () => {

    if (!incident) {
      return "Awaiting route analysis";
    }


    const alternateRoutes = [
      "Western Express Highway",
      "SV Road",
      "LBS Marg",
      "Dr. Ambedkar Road",
      "Eastern Express Highway",
    ];


    const availableRoutes = alternateRoutes.filter(
      (route) => route !== incident.route
    );


    return availableRoutes[incident.id % availableRoutes.length];

  };


  /* ==========================================
     CALCULATE ALTERNATE ETA
  ========================================== */

  const getAlternateETA = () => {

    if (!incident) {
      return "-- mins";
    }


    const mainETA = parseInt(incident.eta) || 5;

    return `${mainETA + 3} mins`;

  };


  /* ==========================================
     GET TRAFFIC CONDITION
  ========================================== */

  const getTrafficCondition = () => {

    if (!incident) {
      return "Unknown";
    }


    if (incident.priority === "Critical") {
      return "Heavy";
    }


    if (incident.priority === "High") {
      return "Heavy";
    }


    if (incident.priority === "Medium") {
      return "Moderate";
    }


    return "Light";

  };


  /* ==========================================
     GET TRAFFIC CLASS
  ========================================== */

  const getTrafficClass = () => {

    const condition = getTrafficCondition();

    if (condition === "Heavy") {
      return "heavy";
    }

    if (condition === "Moderate") {
      return "moderate";
    }

    if (condition === "Light") {
      return "light";
    }

    return "unknown";

  };


  /* ==========================================
     EMPTY STATE
  ========================================== */

  if (!incident) {

    return (

      <div className="route-optimization">

        <div className="route-header">

          <div className="route-title">

            <div className="route-icon">
              🛣️
            </div>

            <div>

              <h2>
                Route Optimization
              </h2>

              <p>
                AI-powered route selection
              </p>

            </div>

          </div>


          <div className="route-status standby">
            STANDBY
          </div>

        </div>


        <div className="route-empty">

          <div className="empty-route-icon">
            🛣️
          </div>

          <h3>
            No Route Analysis
          </h3>

          <p>
            Select an incident from the live traffic
            map to calculate the fastest response route.
          </p>

        </div>

      </div>

    );

  }


  /* ==========================================
     ACTIVE ROUTE
  ========================================== */

  return (

    <div className="route-optimization">

      {/* ======================================
          HEADER
      ====================================== */}

      <div className="route-header">

        <div className="route-title">

          <div className="route-icon">
            🛣️
          </div>

          <div>

            <h2>
              Route Optimization
            </h2>

            <p>
              AI-powered route selection
            </p>

          </div>

        </div>


        <div className="route-status active">

          <span></span>

          ACTIVE

        </div>

      </div>


      {/* ======================================
          CALCULATING
      ====================================== */}

      {isCalculating && (

        <div className="route-calculating">

          <div className="route-spinner"></div>

          <div>

            <strong>
              Calculating optimal route...
            </strong>

            <p>
              Analyzing traffic conditions
            </p>

          </div>

        </div>

      )}


      {/* ======================================
          INCIDENT
      ====================================== */}

      <div className="route-incident">

        <div className="route-incident-icon">

          {incident.type === "Accident"
            ? "🚨"
            : incident.type === "Ambulance"
            ? "🚑"
            : incident.type === "Traffic"
            ? "🚦"
            : "⚠️"}

        </div>


        <div>

          <span>
            DESTINATION
          </span>

          <h3>
            {incident.location}
          </h3>

        </div>


        <div className="route-unit">

          🚑 {incident.unit}

        </div>

      </div>


      {/* ======================================
          RECOMMENDED ROUTE
      ====================================== */}

      {routeReady && (

        <>

          <div className="recommended-route">

            <div className="recommended-header">

              <div>

                <span>
                  RECOMMENDED ROUTE
                </span>

                <h3>
                  🟢 {incident.route}
                </h3>

              </div>


              <div className="fastest-badge">
                ⚡ FASTEST
              </div>

            </div>


            <div className="route-stats">

              <div>

                <span>
                  ETA
                </span>

                <strong>
                  {incident.eta}
                </strong>

              </div>


              <div>

                <span>
                  TRAFFIC
                </span>

                <strong
                  className={`traffic-${getTrafficClass()}`}
                >
                  {getTrafficCondition()}
                </strong>

              </div>


              <div>

                <span>
                  PRIORITY
                </span>

                <strong>
                  {incident.priority}
                </strong>

              </div>

            </div>

          </div>


          {/* ==================================
              ALTERNATE ROUTE
          ================================== */}

          <div className="alternate-route">

            <div className="alternate-header">

              <div>

                <span>
                  ALTERNATE ROUTE
                </span>

                <h3>
                  🔀 {getAlternateRoute()}
                </h3>

              </div>


              <span className="alternate-eta">
                {getAlternateETA()}
              </span>

            </div>


            <div className="alternate-info">

              <span>
                Slightly longer route
              </span>

              <span>
                Traffic: Moderate
              </span>

            </div>

          </div>


          {/* ==================================
              AI EXPLANATION
          ================================== */}

          <div className="route-ai">

            <div className="route-ai-icon">
              🤖
            </div>


            <div>

              <span>
                AI ROUTE DECISION
              </span>

              <p>

                The recommended route was selected
                based on estimated response time,
                current traffic conditions and
                incident priority.

              </p>

            </div>

          </div>

        </>

      )}


      {/* ======================================
          FOOTER
      ====================================== */}

      <div className="route-footer">

        <div>

          <span className="route-live-dot"></span>

          Traffic conditions monitored live

        </div>


        <span>
          {trafficData.length} network incidents
        </span>

      </div>

    </div>

  );

}


export default RouteOptimization;