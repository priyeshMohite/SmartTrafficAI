import "./MapPanel.css";

import { useState } from "react";

import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
} from "react-leaflet";

import L from "leaflet";

import "leaflet/dist/leaflet.css";

import useLiveIncidents from "../../hooks/useLiveIncidents";


/* ==========================================
   MARKER SHADOW
========================================== */

const markerShadow =
  "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png";


/* ==========================================
   MARKER ICONS
========================================== */

const accidentIcon = new L.Icon({

  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png",

  shadowUrl: markerShadow,

  iconSize: [25, 41],

  iconAnchor: [12, 41],

  popupAnchor: [1, -34],

});


const policeIcon = new L.Icon({

  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png",

  shadowUrl: markerShadow,

  iconSize: [25, 41],

  iconAnchor: [12, 41],

  popupAnchor: [1, -34],

});


const ambulanceIcon = new L.Icon({

  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png",

  shadowUrl: markerShadow,

  iconSize: [25, 41],

  iconAnchor: [12, 41],

  popupAnchor: [1, -34],

});


const parkingIcon = new L.Icon({

  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-yellow.png",

  shadowUrl: markerShadow,

  iconSize: [25, 41],

  iconAnchor: [12, 41],

  popupAnchor: [1, -34],

});


const potholeIcon = new L.Icon({

  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-violet.png",

  shadowUrl: markerShadow,

  iconSize: [25, 41],

  iconAnchor: [12, 41],

  popupAnchor: [1, -34],

});


const trafficIcon = new L.Icon({

  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-orange.png",

  shadowUrl: markerShadow,

  iconSize: [25, 41],

  iconAnchor: [12, 41],

  popupAnchor: [1, -34],

});


/* ==========================================
   MAP PANEL
========================================== */

function MapPanel({
  setSelectedIncident,
}) {

  const mumbai = [
    19.076,
    72.8777,
  ];


  /* ========================================
     LIVE INCIDENTS
  ======================================== */

  const incidents =
    useLiveIncidents();


  /* ========================================
     FILTER
  ======================================== */

  const [filter, setFilter] =
    useState("All");


  /* ========================================
     SEARCH
  ======================================== */

  const [search, setSearch] =
    useState("");


  /* ========================================
     GET ICON
  ======================================== */

  const getIcon = (type) => {

    switch (type) {

      case "Accident":
        return accidentIcon;

      case "Traffic":
        return trafficIcon;

      case "Police":
        return policeIcon;

      case "Ambulance":
        return ambulanceIcon;

      case "Parking":
        return parkingIcon;

      case "Pothole":
        return potholeIcon;

      default:
        return accidentIcon;

    }

  };


  /* ========================================
     FILTER + SEARCH
  ======================================== */

  const filteredData =
    incidents.filter((item) => {

      const matchesFilter =
        filter === "All" ||
        item.type === filter;


      const matchesSearch =
        item.location
          .toLowerCase()
          .includes(
            search.toLowerCase()
          );


      return (
        matchesFilter &&
        matchesSearch
      );

    });


  return (

    <div className="map-panel">


      {/* ====================================
          HEADER
      ==================================== */}

      <div className="map-header">


        <div className="map-title">

          <h2>
            🗺️ Live Traffic Map
          </h2>


          <span className="map-live-status">

            <span className="map-live-dot"></span>

            LIVE

          </span>

        </div>


        {/* ==================================
            CONTROLS
        ================================== */}

        <div className="controls">


          <select
            className="filter-dropdown"

            value={filter}

            onChange={(e) =>
              setFilter(e.target.value)
            }
          >

            <option value="All">
              All
            </option>

            <option value="Accident">
              Accident
            </option>

            <option value="Traffic">
              Traffic
            </option>

            <option value="Police">
              Police
            </option>

            <option value="Ambulance">
              Ambulance
            </option>

            <option value="Parking">
              Parking
            </option>

            <option value="Pothole">
              Pothole
            </option>

          </select>


          <input
            className="search-box"

            type="text"

            placeholder="Search Location..."

            value={search}

            onChange={(e) =>
              setSearch(e.target.value)
            }

          />

        </div>

      </div>


      {/* ====================================
          MAP
      ==================================== */}

      <MapContainer

        center={mumbai}

        zoom={12}

        scrollWheelZoom={true}

        className="traffic-map"

      >

        <TileLayer

          attribution="&copy; OpenStreetMap contributors"

          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"

        />


        {/* ==================================
            LIVE MARKERS
        ================================== */}

        {filteredData.map(
          (item) => (

            <Marker

              key={item.id}

              position={item.position}

              icon={getIcon(item.type)}

              eventHandlers={{

                click: () => {

                  setSelectedIncident(
                    item
                  );

                },

              }}

            >

              <Popup>

                <div className="incident-popup">


                  <div className="popup-title">

                    {item.type}

                  </div>


                  <div className="popup-location">

                    📍 {item.location}

                  </div>


                  <div className="popup-info">

                    <strong>
                      Priority:
                    </strong>

                    {" "}

                    <span
                      className={`priority-${item.priority.toLowerCase()}`}
                    >
                      {item.priority}
                    </span>

                  </div>


                  <div className="popup-info">

                    <strong>
                      Unit:
                    </strong>

                    {" "}

                    {item.unit}

                  </div>


                  <div className="popup-info">

                    <strong>
                      ETA:
                    </strong>

                    {" "}

                    {item.eta}

                  </div>


                  <div className="popup-info">

                    <strong>
                      Route:
                    </strong>

                    {" "}

                    {item.route}

                  </div>


                </div>

              </Popup>

            </Marker>

          )
        )}

      </MapContainer>


      {/* ====================================
          MAP FOOTER
      ==================================== */}

      <div className="map-footer">


        <span>

          <span className="map-footer-dot"></span>

          {filteredData.length} active
          incidents

        </span>


        <span>

          Live updates every 5 seconds

        </span>


      </div>


    </div>

  );

}


export default MapPanel;