import "./RecentIncidents.css";
import trafficData from "../../data/trafficData";

function RecentIncidents() {
  return (
    <div className="recent-incidents">
      <h2>📋 Recent Incidents</h2>

      {trafficData.map((incident) => (
        <div className="incident-card" key={incident.id}>
          <div>
            <h3>{incident.type}</h3>
            <p>{incident.location}</p>
          </div>

          <div className="incident-info">
            <span className={`status ${incident.priority.toLowerCase()}`}>
              {incident.priority}
            </span>

            <small>{incident.eta}</small>
          </div>
        </div>
      ))}
    </div>
  );
}

export default RecentIncidents;