import "./IncidentPanel.css";

import { useEffect, useState } from "react";


function IncidentPanel({ incident }) {

  const [status, setStatus] = useState("Detected");

  const [dispatching, setDispatching] = useState(false);


  /* ==========================================
     RESET STATUS WHEN INCIDENT CHANGES
  ========================================== */

  useEffect(() => {

    setStatus("Detected");

    setDispatching(false);

  }, [incident]);


  /* ==========================================
     DISPATCH UNIT
  ========================================== */

  const handleDispatch = () => {

    setDispatching(true);

    setStatus("Dispatching");


    setTimeout(() => {

      setDispatching(false);

      setStatus("Responding");

    }, 1500);

  };


  /* ==========================================
     RESOLVE INCIDENT
  ========================================== */

  const handleResolve = () => {

    setStatus("Resolved");

  };


  /* ==========================================
     EMPTY STATE
  ========================================== */

  if (!incident) {

    return (

      <div className="incident-panel">

        <div className="incident-header">

          <div className="incident-heading">

            <div className="incident-icon">
              🤖
            </div>

            <div>

              <h2>
                Incident Management
              </h2>

              <p>
                AI-powered incident response
              </p>

            </div>

          </div>


          <div className="incident-status standby">
            STANDBY
          </div>

        </div>


        <div className="incident-empty">

          <div className="incident-empty-icon">
            🚨
          </div>

          <h3>
            No Incident Selected
          </h3>

          <p>
            Select an incident from the live traffic
            map to view response information.
          </p>

        </div>

      </div>

    );

  }


  /* ==========================================
     STATUS CLASS
  ========================================== */

  const getStatusClass = () => {

    switch (status) {

      case "Dispatching":
        return "dispatching";

      case "Responding":
        return "responding";

      case "Resolved":
        return "resolved";

      default:
        return "detected";

    }

  };


  /* ==========================================
     PRIORITY CLASS
  ========================================== */

  const getPriorityClass = () => {

    switch (incident.priority) {

      case "Critical":
        return "critical";

      case "High":
        return "high";

      case "Medium":
        return "medium";

      default:
        return "low";

    }

  };


  return (

    <div className="incident-panel">


      {/* ======================================
          HEADER
      ====================================== */}

      <div className="incident-header">

        <div className="incident-heading">

          <div className="incident-icon">
            🚨
          </div>

          <div>

            <h2>
              Incident Management
            </h2>

            <p>
              AI-powered incident response
            </p>

          </div>

        </div>


        <div
          className={`incident-status ${getStatusClass()}`}
        >

          <span></span>

          {status.toUpperCase()}

        </div>

      </div>


      {/* ======================================
          INCIDENT SUMMARY
      ====================================== */}

      <div className="incident-summary">


        <div className="incident-main">


          <div className="incident-type-icon">

            {incident.type === "Accident"
              ? "🚨"
              : incident.type === "Ambulance"
              ? "🚑"
              : incident.type === "Traffic"
              ? "🚦"
              : incident.type === "Police"
              ? "👮"
              : "⚠️"}

          </div>


          <div>

            <span className="incident-label">
              INCIDENT
            </span>

            <h3>
              {incident.type}
            </h3>

            <p>
              📍 {incident.location}
            </p>

          </div>

        </div>


        <div
          className={`priority-badge ${getPriorityClass()}`}
        >
          {incident.priority}
        </div>

      </div>


      {/* ======================================
          INFORMATION GRID
      ====================================== */}

      <div className="incident-grid">


        {/* UNIT */}

        <div className="incident-info">

          <span>
            🚑 ASSIGNED UNIT
          </span>

          <strong>
            {incident.unit}
          </strong>

        </div>


        {/* ETA */}

        <div className="incident-info">

          <span>
            ⏱️ RESPONSE ETA
          </span>

          <strong>
            {incident.eta}
          </strong>

        </div>


        {/* ROUTE */}

        <div className="incident-info">

          <span>
            🛣️ RECOMMENDED ROUTE
          </span>

          <strong>
            {incident.route}
          </strong>

        </div>


        {/* RESPONSE */}

        <div className="incident-info">

          <span>
            📡 RESPONSE STATUS
          </span>

          <strong className={getStatusClass()}>
            {status}
          </strong>

        </div>

      </div>


      {/* ======================================
          AI RECOMMENDATION
      ====================================== */}

      <div className="ai-recommendation">


        <div className="ai-recommendation-icon">
          🤖
        </div>


        <div>

          <span>
            AI RECOMMENDATION
          </span>

          <p>

            {incident.priority === "Critical"
              ? "Immediate emergency response recommended. Dispatch the nearest available unit and prioritize the optimized route."
              : incident.priority === "High"
              ? "High-priority response required. Dispatch the assigned unit using the recommended route."
              : "Monitor the incident and dispatch the assigned unit using the recommended route."}

          </p>

        </div>

      </div>


      {/* ======================================
          ACTIONS
      ====================================== */}

      <div className="incident-actions">


        <button
          className="dispatch-button"
          onClick={handleDispatch}
          disabled={
            dispatching ||
            status === "Responding" ||
            status === "Resolved"
          }
        >

          {dispatching
            ? "⏳ Dispatching..."
            : status === "Responding"
            ? "🚑 Unit Dispatched"
            : "🚑 Dispatch Unit"}

        </button>


        <button
          className="resolve-button"
          onClick={handleResolve}
          disabled={status === "Resolved"}
        >

          {status === "Resolved"
            ? "✅ Incident Resolved"
            : "✓ Mark Resolved"}

        </button>

      </div>


      {/* ======================================
          FOOTER
      ====================================== */}

      <div className="incident-footer">

        <div>

          <span className="incident-live-dot"></span>

          Incident monitoring active

        </div>


        <span>
          System status: Online
        </span>

      </div>

    </div>

  );

}


export default IncidentPanel;