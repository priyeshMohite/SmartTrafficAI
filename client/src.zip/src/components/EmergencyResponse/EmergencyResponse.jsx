import "./EmergencyResponse.css";

import { useEffect, useState } from "react";


function EmergencyResponse({ incident }) {

  const [remainingSeconds, setRemainingSeconds] = useState(null);
  const [status, setStatus] = useState("Standby");


  /* ==========================================
     START RESPONSE WHEN INCIDENT IS SELECTED
  ========================================== */

  useEffect(() => {

    if (!incident) {

      setRemainingSeconds(null);
      setStatus("Standby");

      return;

    }


    const minutes = parseInt(incident.eta) || 5;

    setRemainingSeconds(minutes * 60);

    setStatus("Dispatched");


  }, [incident]);


  /* ==========================================
     COUNTDOWN TIMER
  ========================================== */

  useEffect(() => {

    if (
      remainingSeconds === null ||
      remainingSeconds <= 0
    ) {
      return;
    }


    const timer = setInterval(() => {

      setRemainingSeconds((previous) => {

        if (previous <= 1) {

          setStatus("Arrived");

          return 0;

        }

        return previous - 1;

      });

    }, 1000);


    return () => clearInterval(timer);

  }, [remainingSeconds]);


  /* ==========================================
     FORMAT TIME
  ========================================== */

  const formatTime = (seconds) => {

    if (seconds === null) {
      return "--:--";
    }


    const minutes = Math.floor(seconds / 60);

    const secs = seconds % 60;


    return `${String(minutes).padStart(2, "0")}:${String(
      secs
    ).padStart(2, "0")}`;

  };


  /* ==========================================
     PROGRESS
  ========================================== */

  const getProgress = () => {

    if (!incident || remainingSeconds === null) {
      return 0;
    }


    const totalSeconds =
      (parseInt(incident.eta) || 5) * 60;


    return Math.max(
      0,
      Math.min(
        100,
        ((totalSeconds - remainingSeconds) /
          totalSeconds) *
          100
      )
    );

  };


  /* ==========================================
     EMPTY STATE
  ========================================== */

  if (!incident) {

    return (

      <div className="emergency-response">

        <div className="emergency-header">

          <div className="emergency-title">

            <div className="emergency-icon">
              🚑
            </div>

            <div>

              <h2>
                Emergency Response
              </h2>

              <p>
                Emergency unit coordination
              </p>

            </div>

          </div>


          <span className="response-standby">
            STANDBY
          </span>

        </div>


        <div className="emergency-empty">

          <div className="empty-response-icon">
            🚑
          </div>

          <h3>
            No Active Emergency
          </h3>

          <p>
            Select an accident or emergency
            incident from the map to activate
            emergency response tracking.
          </p>

        </div>

      </div>

    );

  }


  /* ==========================================
     ACTIVE RESPONSE
  ========================================== */

  return (

    <div className="emergency-response">

      {/* ======================================
          HEADER
      ====================================== */}

      <div className="emergency-header">

        <div className="emergency-title">

          <div className="emergency-icon">
            🚑
          </div>

          <div>

            <h2>
              Emergency Response
            </h2>

            <p>
              Emergency unit coordination
            </p>

          </div>

        </div>


        <span
          className={`response-status ${status.toLowerCase()}`}
        >

          {status}

        </span>

      </div>


      {/* ======================================
          INCIDENT
      ====================================== */}

      <div className="response-incident">

        <div className="incident-response-icon">

          {incident.type === "Accident"
            ? "🚨"
            : incident.type === "Ambulance"
            ? "🚑"
            : "⚠️"}

        </div>


        <div>

          <span>
            ACTIVE INCIDENT
          </span>

          <h3>
            {incident.type}
          </h3>

          <p>
            📍 {incident.location}
          </p>

        </div>


        <div
          className={`response-priority ${
            incident.priority?.toLowerCase()
          }`}
        >

          {incident.priority}

        </div>

      </div>


      {/* ======================================
          RESPONSE DETAILS
      ====================================== */}

      <div className="response-details">

        <div className="response-detail">

          <span className="response-detail-icon">
            🚑
          </span>

          <div>

            <span>
              ASSIGNED UNIT
            </span>

            <strong>
              {incident.unit}
            </strong>

          </div>

        </div>


        <div className="response-detail">

          <span className="response-detail-icon">
            🛣️
          </span>

          <div>

            <span>
              ROUTE
            </span>

            <strong>
              {incident.route}
            </strong>

          </div>

        </div>

      </div>


      {/* ======================================
          ETA
      ====================================== */}

      <div className="eta-section">

        <div className="eta-header">

          <div>

            <span>
              ESTIMATED ARRIVAL
            </span>

            <strong>
              {formatTime(remainingSeconds)}
            </strong>

          </div>


          <div className="eta-live">

            <span></span>

            LIVE

          </div>

        </div>


        <div className="progress-container">

          <div
            className="progress-bar"
            style={{
              width: `${getProgress()}%`,
            }}
          ></div>

        </div>


        <div className="progress-labels">

          <span>
            Dispatched
          </span>

          <span>
            {status === "Arrived"
              ? "Arrived"
              : "En route"}
          </span>

        </div>

      </div>


      {/* ======================================
          RESPONSE FOOTER
      ====================================== */}

      <div className="response-footer">

        <div>

          <span className="footer-dot"></span>

          Emergency response active

        </div>


        <span>
          Monitoring unit location
        </span>

      </div>

    </div>

  );

}


export default EmergencyResponse;