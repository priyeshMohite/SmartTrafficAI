import "./AlertsPanel.css";

import trafficData from "../../data/trafficData";


function AlertsPanel() {

  const alerts = trafficData
    .filter(
      (item) =>
        item.priority === "Critical" ||
        item.priority === "High"
    )
    .slice(0, 5);


  return (
    <div className="alerts-panel">

      {/* ======================================
          HEADER
      ====================================== */}

      <div className="alerts-header">

        <div>

          <h2>
            🔔 Live Alerts
          </h2>

          <p>
            Priority traffic incidents
          </p>

        </div>


        <div className="alert-count">

          {alerts.length}

        </div>

      </div>


      {/* ======================================
          ALERT LIST
      ====================================== */}

      <div className="alerts-list">

        {alerts.length === 0 ? (

          <div className="no-alerts">

            <div className="no-alert-icon">
              ✅
            </div>

            <p>
              No high-priority alerts
            </p>

          </div>

        ) : (

          alerts.map((alert) => (

            <div
              className={`alert-item ${
                alert.priority.toLowerCase()
              }`}
              key={alert.id}
            >

              {/* ICON */}

              <div className="alert-icon">

                {alert.type === "Accident"
                  ? "🚨"
                  : alert.type === "Ambulance"
                  ? "🚑"
                  : alert.type === "Traffic"
                  ? "🚦"
                  : "⚠️"}

              </div>


              {/* CONTENT */}

              <div className="alert-content">

                <div className="alert-title-row">

                  <strong>
                    {alert.type}
                  </strong>

                  <span
                    className={`alert-priority ${
                      alert.priority.toLowerCase()
                    }`}
                  >
                    {alert.priority}
                  </span>

                </div>


                <p>
                  📍 {alert.location}
                </p>


                <span className="alert-eta">

                  ⏱ ETA: {alert.eta}

                </span>

              </div>

            </div>

          ))

        )}

      </div>


      {/* ======================================
          FOOTER
      ====================================== */}

      <div className="alerts-footer">

        <span className="alert-live-dot"></span>

        Monitoring active

      </div>

    </div>
  );
}


export default AlertsPanel;