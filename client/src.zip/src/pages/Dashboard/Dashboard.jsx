import { useState } from "react";

import "./Dashboard.css";

import Navbar from "../../components/Navbar/Navbar";
import Sidebar from "../../components/Sidebar/Sidebar";
import DashboardCards from "../../components/DashboardCards/DashboardCards";
import LiveStatus from "../../components/LiveStatus/LiveStatus";
import MapPanel from "../../components/MapPanel/MapPanel";
import AlertsPanel from "../../components/AlertsPanel/AlertsPanel";
import RecentIncidents from "../../components/RecentIncidents/RecentIncidents";
import WeatherCard from "../../components/WeatherCard/WeatherCard";
import Analytics from "../../components/Analytics/Analytics";
import IncidentPanel from "../../components/IncidentPanel/IncidentPanel";

import useTrafficSimulation from "../../hooks/useTrafficSimulation";


function Dashboard() {

  /* ==========================================
     SELECTED INCIDENT
  ========================================== */

  const [selectedIncident, setSelectedIncident] =
    useState(null);


  /* ==========================================
     SHARED LIVE TRAFFIC DATA
  ========================================== */

  const stats = useTrafficSimulation();


  return (
    <>
      {/* ======================================
          NAVBAR
      ====================================== */}

      <Navbar />


      <div className="dashboard-container">


        {/* ====================================
            SIDEBAR
        ==================================== */}

        <Sidebar />


        {/* ====================================
            MAIN CONTENT
        ==================================== */}

        <div className="content">


          {/* ==================================
              PAGE HEADER
          ================================== */}

          <h1>
            Welcome Back, Admin 👋
          </h1>

          <p>
            Traffic Monitoring Command Center
          </p>


          {/* ==================================
              DASHBOARD CARDS
          ================================== */}

          <DashboardCards
            stats={stats}
          />


          {/* ==================================
              LIVE SYSTEM STATUS
          ================================== */}

          <LiveStatus
            stats={stats}
          />


          {/* ==================================
              MAP + ALERTS
          ================================== */}

          <div className="middle-section">


            <MapPanel
              setSelectedIncident={
                setSelectedIncident
              }
            />


            <AlertsPanel />


          </div>


          {/* ==================================
              INCIDENT MANAGEMENT
          ================================== */}

          <IncidentPanel
            incident={selectedIncident}
          />


          {/* ==================================
              RECENT INCIDENTS + WEATHER
          ================================== */}

          <div className="bottom-section">


            <RecentIncidents />


            <WeatherCard />


          </div>


          {/* ==================================
              ANALYTICS
          ================================== */}

          <Analytics
            stats={stats}
          />


        </div>

      </div>
    </>
  );
}


export default Dashboard;