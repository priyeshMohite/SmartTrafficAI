import { useEffect, useState } from "react";

import trafficData from "../data/trafficData";


function useLiveIncidents() {

  const [incidents, setIncidents] = useState(
    trafficData
  );


  useEffect(() => {

    const interval = setInterval(() => {

      setIncidents((previousIncidents) => {

        let updatedIncidents = [
          ...previousIncidents
        ];


        /* ======================================
           RANDOM CHANCE FOR NEW INCIDENT
        ====================================== */

        const shouldCreateIncident =
          Math.random() < 0.25;


        if (shouldCreateIncident) {

          const incidentTypes = [
            "Accident",
            "Traffic",
            "Police",
            "Ambulance",
            "Parking",
            "Pothole",
          ];


          const locations = [
            "Bandra",
            "Andheri",
            "Dadar",
            "Sion",
            "Kurla",
            "Lower Parel",
            "Powai",
            "Worli",
            "Goregaon",
            "Borivali",
          ];


          const priorities = [
            "Low",
            "Medium",
            "High",
            "Critical",
          ];


          const units = [
            "Traffic Police Unit 5",
            "Traffic Police Unit 7",
            "Traffic Police Unit 9",
            "Ambulance 3",
            "Ambulance 4",
            "Police Unit 2",
            "Road Repair Team",
          ];


          const routes = [
            "Western Express Highway",
            "Eastern Express Highway",
            "SV Road",
            "LBS Marg",
            "Dr. Ambedkar Road",
            "Link Road",
            "Jogeshwari-Vikhroli Link Road",
          ];


          const randomType =
            incidentTypes[
              Math.floor(
                Math.random() *
                incidentTypes.length
              )
            ];


          const randomLocation =
            locations[
              Math.floor(
                Math.random() *
                locations.length
              )
            ];


          const randomPriority =
            priorities[
              Math.floor(
                Math.random() *
                priorities.length
              )
            ];


          const randomUnit =
            units[
              Math.floor(
                Math.random() *
                units.length
              )
            ];


          const randomRoute =
            routes[
              Math.floor(
                Math.random() *
                routes.length
              )
            ];


          /* ====================================
             MUMBAI COORDINATES
          ==================================== */

          const latitude =
            18.98 +
            Math.random() * 0.18;


          const longitude =
            72.80 +
            Math.random() * 0.15;


          /* ====================================
             CREATE INCIDENT
          ==================================== */

          const newIncident = {

            id: `live-${Date.now()}`,

            type: randomType,

            location:
              `${randomLocation} Junction`,

            position: [
              latitude,
              longitude,
            ],

            priority: randomPriority,

            unit: randomUnit,

            eta:
              `${Math.floor(
                Math.random() * 15
              ) + 2} mins`,

            route: randomRoute,

          };


          updatedIncidents = [
            ...updatedIncidents,
            newIncident,
          ];

        }


        /* ======================================
           KEEP ONLY LAST 12 INCIDENTS
        ====================================== */

        if (
          updatedIncidents.length > 12
        ) {

          updatedIncidents =
            updatedIncidents.slice(-12);

        }


        return updatedIncidents;

      });

    }, 5000);


    return () => {
      clearInterval(interval);
    };

  }, []);


  return incidents;

}


export default useLiveIncidents;